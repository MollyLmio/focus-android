package org.mozilla.focus.web;

import android.webkit.WebView;

public interface IFindListener extends WebView.FindListener {}
