// Just some token we are looking for on disk
const KANGAROO = true;
