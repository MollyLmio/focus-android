---
name: "\U0001F41E Bug report"
about: Create a report to help us improve

---

## Steps to reproduce

### Expected behavior

### Actual behavior

### Device information

* Android device: ?
* Focus version: ?
