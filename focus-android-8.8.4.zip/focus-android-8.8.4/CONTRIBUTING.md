# Contributing to Focus for Android

Please see our guidelines in our shared-docs repo:
https://github.com/mozilla-mobile/shared-docs/blob/master/android/CONTRIBUTING.md
